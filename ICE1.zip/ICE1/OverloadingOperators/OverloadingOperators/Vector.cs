﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Net.WebRequestMethods;

namespace OverloadingOperators
{
     class Vector
    {
        public int X {  get; set; }
        public int Y { get; set; }
        public Vector(int x, int y)
        {
            X = x;
            Y = y;
        }
        public Vector Add(Vector other)
        {
            return new Vector(X + other.X, Y + other.Y);
        }
        public static Vector operator +(Vector v1, Vector v2)
        {
            return new Vector(v1.X + v2.X, v1.Y + v2.Y);
        }
        public static Vector operator -(Vector v1, Vector v2)
        {
            return new Vector(v1.X - v2.X, v1.Y - v2.Y);
        }
        public static bool operator ==(Vector v1, Vector v2)
        {
            if (ReferenceEquals(v1, v2))
            {
                return true;
            }
            return  (v1.X == v2.X && v1.Y == v2.Y);
        }
        public static bool operator !=(Vector v1, Vector v2)
        {
            if (ReferenceEquals(v1, v2))
            {
                return false;
            }
            
            return  (v1.X != v2.X && v1.Y != v2.Y);
        }
       //Equals  method 1 from (Microsoft, 2026).
        public  bool Equals(Vector v1, Vector v2)
        {
            if (ReferenceEquals(v1, v2))
            {
                return true;
            }
            return (v1.X == v2.X && v1.Y == v2.Y);
        }
        //Equals  method 2 from (Microsoft, 2026).
        public bool Equals( Vector v2)
        {
            if (v2 is Vector v1)
            {
                return this==v2;
            }
            return false;
        }
        //Hash method from (Microsoft, 2026).
        public int GetHashCode( Vector v2)
        {
            
            return HashCode.Combine(this.X == v2.X && this.Y == v2.Y);
        }
    }
}



//REFERENCES
//Microsoft, 2026. Generate Equals and GetHashCode method overrides in Visual Studio. [online] Available at:
//< http://learn.microsoft.com/en-us/visualstudio/ide/reference/generate-equals-gethashcode-methods?view=visualstudio>
// [Accessed 23 July 2026].