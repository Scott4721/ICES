﻿namespace OverloadingOperators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vector v1 = new Vector(6, 8);
            Vector v2 = new Vector(8, 9);
            Vector res1 = v1.Add(v2);
            Vector res2 = v1 + (v2);
            Vector res3 = v1 - (v2);
            res1.GetHashCode();
            bool not = v1 != (v2);
            bool equal = v1 == (v2);
            bool equal1 = v1.Equals((v2));
            bool equal2 = v1.Equals(v1, v2);
            
            int i = v1.GetHashCode(v2);
            Console.WriteLine($"Result: {res1.X}, {res1.Y}");
            Console.WriteLine($"Result 2: {res2.X}, {res2.Y}");
            Console.WriteLine($"Result 3: {res3.X}, {res3.Y}");
            Console.WriteLine($"is Equal: {equal}");
            Console.WriteLine($"is Equal: {equal1}");
            Console.WriteLine($"is Equal: {equal2}");
            Console.WriteLine($"is not equal: {not}");
            Console.WriteLine($"hash: {i}");
            
        }
    }
}
