﻿using System.Diagnostics;

namespace Logging
{
    internal class Program
    {
        private static bool run = true;
        static void Main(string[] args)
        {
            Console.WriteLine("Monitoring");
            Thread proc = new Thread(MonitorProcesses);
            Thread log = new Thread(Log);

            proc.Start();
            log.Start();

            Console.WriteLine("Press Enter to stop rnning");
            Console.ReadLine();
            run = false;
            proc.Join();
            log.Join();
            Console.WriteLine("stopped");
        }

        static void MonitorProcesses()
        {
            while (run)
            {
                Console.WriteLine("\n\nRunning Process:");

                Process[] processes = Process.GetProcesses();

                foreach (Process p in processes)
                {
                    try
                    {
                        using (p)
                        {
                            Console.WriteLine("Name: " + p.ProcessName + ", ID: " + p.Id);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                    Console.WriteLine("------------------");
                    Thread.Sleep(5000);
                }
            }
        }
        static void Log()
        {
            using (StreamWriter sw = new StreamWriter("log.txt", true))
            {

                while (run)
                {
                    sw.WriteLine("LOG @ " + DateTime.Now);
                    sw.Flush();
                    Thread.Sleep(2000);
                }
            }
        }

        
    }
    
}



